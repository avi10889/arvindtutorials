 <!-- CSS-->
  <link href="<?php echo base_url().ADMIN_ASSETS;?>/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url().ADMIN_ASSETS;?>/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url().ADMIN_ASSETS;?>/css/datatables.min.css" rel="stylesheet">
  <link href="<?php echo base_url().ADMIN_ASSETS;?>/css/sb-admin.min.css" rel="stylesheet">
  <link href="<?php echo base_url().ADMIN_ASSETS;?>/vendor/bootstrap/css/bootstrap-datetimepicker.css" rel="stylesheet">
 <link href="<?php echo base_url().ADMIN_ASSETS;?>/css/jquery-ui.min.css" rel="stylesheet">
 <link href="<?php echo base_url().ADMIN_ASSETS;?>/css/jquery-ui-timepicker-addon.css" rel="stylesheet">
  <!--JavaScript-->
  <script src="<?php echo base_url().ADMIN_ASSETS;?>/vendor/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url().ADMIN_ASSETS;?>/vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url().ADMIN_ASSETS;?>/vendor/datatables/datatables.min.js"></script>
  <script src="<?php echo base_url().ADMIN_ASSETS;?>/vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="<?php echo base_url().ADMIN_ASSETS;?>/js/sb-admin.min.js"></script>
 <script src="<?php echo base_url().ADMIN_ASSETS;?>/js/jquery-ui.min.js"></script>
 <script src="<?php echo base_url().ADMIN_ASSETS;?>/js/jquery-ui-timepicker-addon.js"></script>


