<?php
class Admin_model extends CI_Model
{
    //////Add Test Schedule//////
    function add_test_schedule($data)
    {
        $sql = $this->db->insert('test_schedule', $data);
        if ($sql) return $this->db->insert_id();
    }
}
?>